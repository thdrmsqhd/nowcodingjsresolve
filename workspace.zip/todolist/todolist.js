var creatPara = document.querySelector(".wrapper");
console.log(creatPara.p);